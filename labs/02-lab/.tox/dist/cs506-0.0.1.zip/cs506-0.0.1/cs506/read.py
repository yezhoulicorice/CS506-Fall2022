import csv
def read_csv(csv_file_path):
    """
        Given a path to a csv file, return a matrix (list of lists)
        in row major.
    """
    # raise NotImplementedError()
    # df = 
    
    # matrix = df.to_numpy()
    result_2D = []
    result_list = []
    with open(csv_file_path, newline='') as file:
        result_list = list(csv.reader(file))
    # print(result_list)

    for i in result_list:
        buffer = []
        for j in range(0,len(i)):
            ele = i[j]
            try:
                ele = int(ele)
            except:
                ele= ele
            buffer.append(ele)
        

        result_2D.append(buffer)
    return result_2D